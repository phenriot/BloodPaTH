#include <R.h>
#include <Rinternals.h>
#include <stdlib.h> // for NULL
#include <R_ext/Rdynload.h>

/* FIXME: 
   Check these declarations against the C/Fortran source code.
*/

/* .Call calls */
extern SEXP _BlooPaTH_BlooPaTH_model(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP _BlooPaTH_BlooPaTH_model_inter(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP _BlooPaTH_rcpparma_bothproducts(SEXP);
extern SEXP _BlooPaTH_rcpparma_hello_world();
extern SEXP _BlooPaTH_rcpparma_innerproduct(SEXP);
extern SEXP _BlooPaTH_rcpparma_outerproduct(SEXP);
extern SEXP _BlooPaTH_transform_list(SEXP, SEXP);
